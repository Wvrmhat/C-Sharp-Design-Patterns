﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecoratorExampleRobot
{
    class Robot : RoboComponents    // ConcreteComponent
    {
        string Name;

        public Robot(string Name)
        {
            this.Name = Name;
        }

        public override string Details()
        {
            return "Robot: " + this.Name;
        }
    }
}
