﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecoratorExampleRobot
{
    class Program
    {
        static void Main(string[] args)
        {
            RoboComponents firstBot = new Robot("Number 1");        //not of type Robot, it's of type RoboComponents

            RoboComponents myBot = new Robot("Robo777");
            myBot = new SetOfArms(myBot, 2);                // we decorate with a set of arms. It is assigned back to same variable, so we overrite original variable.
            myBot = new Wheels(myBot);              // We parse current object through wheels, which then encapsulates it.

            RoboComponents otherBot = new Robot("R-1000");
            otherBot = new Missiles(otherBot, 20);


            Console.WriteLine(firstBot.Details());
            Console.WriteLine(myBot.Details());
            Console.WriteLine(otherBot.Details());

            Console.ReadLine();
        }
    }
}
