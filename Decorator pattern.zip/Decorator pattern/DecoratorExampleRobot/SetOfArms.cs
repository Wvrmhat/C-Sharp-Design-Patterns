﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecoratorExampleRobot
{
    class SetOfArms : Augementations        //Concrete Decorator
    {
        int ArmType;

        public SetOfArms(RoboComponents DecorateMe, int ArmType) : base(DecorateMe)     //must receive object to be decorated, which is RoboComponents. Inherits specific base
        {
            this.ArmType = ArmType;
        }

        public override string Details()
        {
            if (ArmType == 0)
                return string.Format("{0}\nHas arms with robotic hands.", base.Details());      //if arm is 0 then return base class of augmentations
            else
                return string.Format("{0}\nHas arms with pincers.", base.Details());
        }


    }
}
