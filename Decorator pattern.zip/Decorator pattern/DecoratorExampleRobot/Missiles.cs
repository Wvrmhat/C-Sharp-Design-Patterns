﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecoratorExampleRobot
{
    class Missiles : Augementations
    {
        int Number;

        public Missiles(RoboComponents DecorateMe, int Number): base(DecorateMe)
        {
            this.Number = Number;
        }

        public override string Details()
        {
            return string.Format("{0}\nMissiles: {1}", base.Details(), this.Number);
        }
    }
}
