﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecoratorExampleRobot
{
    class Wheels : Augementations       // ConcreteDecorator
    {
        public Wheels(RoboComponents DecorateMe) : base(DecorateMe)     // receive decorator and parses it to base class
        {

        }

        public override string Details()
        {
            return string.Format("{0}\n Has Wheels.", base.Details());
        }
    }
}
