﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    abstract class PizzaShop //factory base, template where factory method will be called. It is the idea of the shop e.g Debonairs.
    {
        public Pizza OrderPizza(string PizzaName) //method that returns pizza
        {
            Pizza ReturnMe = MakePizza(PizzaName); //calls MakePizza method from a class that derives from PizzaShop

            ReturnMe.MakeDough();
            ReturnMe.AddToppings();
            ReturnMe.Bake();

            return ReturnMe; //returns pizza that has been made
        }
        public abstract Pizza MakePizza(string PizzaName); //method defined as abstract method, it is the factory method as it is defined in base that derived classes provided implementation.
    }
}
