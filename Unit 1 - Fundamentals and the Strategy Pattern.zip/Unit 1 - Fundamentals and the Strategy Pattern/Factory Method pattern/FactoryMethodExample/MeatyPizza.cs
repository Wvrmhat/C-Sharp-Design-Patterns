﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class MeatyPizza : Pizza //concrete product
    {
        public MeatyPizza() //makes use of the virutal methods in the base ProductBase class called Pizza
        {
            this.Name = "Meaty Pizza";
            this.Description = "Pizza with a lot of meat";
            this.Price = 110;
        }
    }
}
