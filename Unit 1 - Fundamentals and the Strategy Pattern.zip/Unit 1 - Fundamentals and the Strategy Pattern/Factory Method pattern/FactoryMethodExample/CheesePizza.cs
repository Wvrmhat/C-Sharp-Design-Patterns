﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class CheesePizza : Pizza //concrete product, derives from base product
    {
        public CheesePizza()
        {
            this.Name = "Cheese Pizza";
            this.Description = "Pizza with cheese";
            this.Price = 90;
        }
    }
}
