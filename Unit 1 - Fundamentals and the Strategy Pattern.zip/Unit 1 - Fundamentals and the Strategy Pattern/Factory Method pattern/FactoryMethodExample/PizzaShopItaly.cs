﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class PizzaShopItaly : PizzaShop //ConcreteProduct
    {
        public override Pizza MakePizza(string PizzaName) //same MakePizza method
        {
            Pizza thePizza = null;

            if (PizzaName == "Cheese Pizza")
                thePizza = new ItalianCheesePizza(); //different type of pizza
            if (PizzaName == "Meaty Pizza")
                thePizza = new MeatyPizza();

            return thePizza;
        }
    }
}
