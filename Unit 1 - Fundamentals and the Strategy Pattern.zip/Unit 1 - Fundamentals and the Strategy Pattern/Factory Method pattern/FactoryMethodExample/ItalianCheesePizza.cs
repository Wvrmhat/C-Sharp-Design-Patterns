﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class ItalianCheesePizza :Pizza //ConcreteProduct class
    {

        public ItalianCheesePizza()
        {
            this.Name = "Cheese Pizza";
            this.Description = "Pizza with goat's cheese";
            this.Price = 90;

        }

        public override void MakeDough() //local variation 
        {
            Console.WriteLine("Making dough with rice flour");
        }
    }
}
