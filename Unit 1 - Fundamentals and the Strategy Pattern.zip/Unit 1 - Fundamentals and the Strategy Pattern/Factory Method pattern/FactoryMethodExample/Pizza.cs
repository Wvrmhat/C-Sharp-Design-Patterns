﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class Pizza //product base class
    {
        public string Name { get; set; } //this is what all pizzas will have
        public string Description { get; set; }
        public decimal Price { get; set; }

        public virtual void MakeDough() //methods can be added
        {
            Console.WriteLine("Making Dough");
        }

        public virtual void AddToppings() //method can be overrided in derived classes
        {
            Console.WriteLine("Adding toppings");
        }

        public virtual void Bake()
        {
            Console.WriteLine("Baking Pizza");
        }
    }
}
