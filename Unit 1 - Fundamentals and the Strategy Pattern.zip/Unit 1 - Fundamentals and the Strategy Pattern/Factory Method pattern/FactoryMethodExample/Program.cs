﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class Program
    {
        static void Main(string[] args)
        {
            PizzaShop debonairs = new PizzaShopSummerstrand(); //creates object debonairs, new statement only used when creating a concrete factor
            Pizza thePizza = debonairs.OrderPizza("Cheese Pizza"); //calls order pizza and returns when we ask for specific type
            Console.WriteLine("Pizza created: " + thePizza.GetType().Name); //returns the object type

            debonairs = new PizzaShopItaly(); //creates another object of type PizzaShopItaly, which inherits from class PizzaShop. Both objects are assigneed the same variable, meaning objects of derived classes can be assigned an instance under the base class
            thePizza = debonairs.OrderPizza("Cheese Pizza");
            Console.WriteLine("Pizza created: " + thePizza.GetType().Name);
            Console.ReadLine();



        }
    }
}
