﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class PizzaShopSummerstrand : PizzaShop //concrete factory
    {
        public override Pizza MakePizza(string PizzaName) //overrides method in factory base
        {
            Pizza thePizza = null; //sets pizza to null in case it has nothing that matches that name

            if (PizzaName == "Cheese Pizza")
                thePizza = new CheesePizza();
            if (PizzaName == "Meaty Pizza")
                thePizza = new MeatyPizza();

            return thePizza;
        }
    }
}
