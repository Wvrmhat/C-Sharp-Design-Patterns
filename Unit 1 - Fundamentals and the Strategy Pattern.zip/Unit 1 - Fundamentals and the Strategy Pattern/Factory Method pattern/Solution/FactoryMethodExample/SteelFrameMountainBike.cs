﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class SteelFrameMountainBike:SteelFrame
    {
        public override void AddWheels()
        {
            Console.WriteLine("Adding mountain bike tyres");
        }
    }
}
