﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class AluminiumFrame : Bike
    {
        public override void CreateFrame()
        {
            Console.WriteLine("Creating an aluminium frame");
        }
    }
}
