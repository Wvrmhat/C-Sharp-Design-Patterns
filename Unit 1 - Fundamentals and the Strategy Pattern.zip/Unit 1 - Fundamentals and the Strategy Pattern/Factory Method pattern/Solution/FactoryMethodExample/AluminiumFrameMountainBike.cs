﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class AluminiumFrameMountainBike:AluminiumFrame
    {
        public override void AddWheels()
        {
            Console.WriteLine("Adding mountain bike tyres");
        }
    }
}
