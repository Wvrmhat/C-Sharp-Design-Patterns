﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class SteelFrame:Bike
    {
        public override void CreateFrame()
        {
            Console.WriteLine("Creating a steel frame");
        }
    }
}
