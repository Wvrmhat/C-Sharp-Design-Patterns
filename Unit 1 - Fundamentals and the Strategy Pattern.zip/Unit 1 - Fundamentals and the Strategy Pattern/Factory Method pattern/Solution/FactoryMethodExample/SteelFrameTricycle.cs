﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class SteelFrameTricycle:SteelFrame
    {
        public override void AddWheels()
        {
            Console.WriteLine("Adding 3 wheels");
        }

        public override void AddHandles()
        {
            Console.WriteLine("Adding raised handles");
        }
    }
}
