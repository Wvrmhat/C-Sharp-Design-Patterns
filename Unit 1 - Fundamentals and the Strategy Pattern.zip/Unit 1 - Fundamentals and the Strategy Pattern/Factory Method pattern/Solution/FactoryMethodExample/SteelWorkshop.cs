﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class SteelWorkshop:BikeCo
    {
        public override Bike BuildBike(string BikeName)
        {
            Bike theBike = null;

            if (BikeName == "Mountain bike")
                theBike = new SteelFrameMountainBike();

            if (BikeName == "Tricycle")
                theBike = new SteelFrameTricycle();

            return theBike;
        }
    }
}
