﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    abstract class Bike
    {
       
        public virtual void CreateFrame()
        {
            Console.WriteLine("Creating the frame");            
        }

        public virtual void AddWheels()
        {
            Console.WriteLine("Adding Wheels");
        }

        public virtual void AddHandles()
        {
            Console.WriteLine("Adding Handles");
        }

        public virtual void AddBrakes()
        {
            Console.WriteLine("Adding Handles");
        }

        public virtual void AddPedals()
        {
            Console.WriteLine("Adding Pedals");
        }

        public virtual void AddSeat()
        {
            Console.WriteLine("Adding Seat");
        }
    }
}
