﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodExample
{
    class AluminiumWorkshop:BikeCo
    {
        public override Bike BuildBike(string BikeName)
        {
            Bike theBike = null;

            if (BikeName == "Mountain bike")
                theBike = new AluminiumFrameMountainBike();

            if (BikeName == "Racing bike")
                theBike = new AluminiumFrameRacingBike();

            return theBike;
        }
    }
}
