﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodTemplate
{
    class ConcreteProductA:ProductBase
    {

    }

    class ConcreteProductB : ProductBase
    {

    }
}
