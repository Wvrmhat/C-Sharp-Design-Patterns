﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StategyExample
{
    abstract class Output
    {
        public abstract void Display(List<int> DisplayMe);
    }

}
