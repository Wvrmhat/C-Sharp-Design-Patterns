﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StategyExample
{
    class DataSet
    {
        public string Name = "";
        public List<int> Values = new List<int>();

        public Sorting Sorter;
        public Output Display;
        public DataSet(string Name, List<int> Values, Sorting Sorter, Output Display)
        {
            this.Name = Name;
            this.Values = Values;
            this.Sorter = Sorter;
            this.Display = Display;
        }
        public void Sort()
        {
            Values = Sorter.Sort(Values);
        }

        public void DisplayList()
        {
            Display.Display(Values);
        }
    }

}
