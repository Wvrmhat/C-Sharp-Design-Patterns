﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StategyExample
{
    class Reverse : Sorting
    {
        public override List<int> Sort(List<int> SortMe)
        {
            SortMe.Sort();
            SortMe.Reverse();
            return SortMe;
        }
    }

}
