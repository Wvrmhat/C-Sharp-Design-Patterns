﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StategyExample
{
    abstract class Sorting
    {
        public abstract List<int> Sort(List<int> SortMe);
    }

}
