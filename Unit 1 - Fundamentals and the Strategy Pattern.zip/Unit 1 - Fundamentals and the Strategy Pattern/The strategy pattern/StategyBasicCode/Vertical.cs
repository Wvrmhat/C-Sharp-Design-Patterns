﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StategyExample
{
    class Vertical : Output
    {
        public override void Display(List<int> DisplayMe)
        {
            foreach (int Current in DisplayMe)
                Console.WriteLine(Current);
        }
    }
}
