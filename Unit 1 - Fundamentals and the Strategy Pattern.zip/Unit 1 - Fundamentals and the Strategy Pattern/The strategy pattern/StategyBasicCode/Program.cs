﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StategyExample
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> Values1 = new List<int>();
            Values1.Add(3);
            Values1.Add(4);
            Values1.Add(1);
            Values1.Add(2);

            List<int> Values2 = new List<int>();
            Values2.Add(3);
            Values2.Add(4);
            Values2.Add(1);
            Values2.Add(2);

            DataSet First = new DataSet("Simple Horizontal", Values1, new Simple(), new Horizontal());
            DataSet Second = new DataSet("Reverse Vertical", Values2, new Reverse(), new Vertical());

            First.Sort();
            Second.Sort();
            First.DisplayList();
            Second.DisplayList();
            Second.Display = new Horizontal();
            Second.DisplayList();

            Console.ReadLine();
        }
    }
}
