﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StategyExample
{
    class Robo : Legs
    {
        public override String Run()
        {
            return "Running on robotic legs.";
        }
    }

}
