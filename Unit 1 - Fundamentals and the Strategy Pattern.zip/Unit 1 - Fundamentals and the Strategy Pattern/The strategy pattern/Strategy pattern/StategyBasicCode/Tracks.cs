﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StategyExample
{
    class Tracks : Legs
    {
        public override string Run()
        {
            return "Rolling on wheeled tracks.";
        }
    }

}
