﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPatternExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Runner First =new Runner(new Robotic());
            Runner Second = new Runner(new Tracks());
            Runner Third = new Runner(new Hover());
            Runner Fourth = new TrackedRunner();

            First.Run();
            Second.Run();
            Third.Run();
            Fourth.Run();

            Console.WriteLine("Changing the behaviour:");
            First.RunnerLegs = new Tracks(); //Robotic will change at runtime to make use of tracks now.
            First.Run();

            Console.ReadLine();
        }
    }
}
