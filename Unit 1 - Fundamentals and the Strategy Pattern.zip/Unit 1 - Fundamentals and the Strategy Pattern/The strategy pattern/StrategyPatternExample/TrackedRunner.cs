﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPatternExample
{
    class TrackedRunner : Runner //client inheriting from runner client
    {
        public TrackedRunner() : base(new Tracks()) //this runner is always associated with tracks behaviour, it has a constructor that initializes base class runner with a set of tracks.
        { }
    }
}
