﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPatternExample
{
    class Robotic : Legs //inherits from base class Legs
    {
        public override string Run()
        {
            return "Running on robotic legs.";
        }
    }
}
