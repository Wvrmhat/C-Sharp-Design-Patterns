﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPatternExample
{
    abstract class Legs //abstract class means we can't create specific implementations
    {
        public abstract String Run(); //abstract method means the class needs to override this method
    }
}
