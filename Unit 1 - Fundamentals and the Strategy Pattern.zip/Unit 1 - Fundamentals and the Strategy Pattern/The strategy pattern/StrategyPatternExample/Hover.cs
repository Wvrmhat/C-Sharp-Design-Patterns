﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPatternExample
{
    class Hover : Legs
    {
        public override string Run()
        {
            return "Hovering on a flame booster.";
        }
    }
}
