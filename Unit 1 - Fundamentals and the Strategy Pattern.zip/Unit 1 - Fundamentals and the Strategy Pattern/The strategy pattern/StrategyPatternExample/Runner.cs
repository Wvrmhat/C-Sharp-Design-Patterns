﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPatternExample
{
    class Runner //client
    {
        public Legs RunnerLegs; //behaviour that can change during runtime, it is hotswappable. Usually private instead of public

        public Runner(Legs RunnerLegs) //constructor that recieves a running behaving/legs.
        {
            this.RunnerLegs = RunnerLegs;
        }

        public void Run() //Run method that calls run on whichever legs are associated with the runner.
     
        {
            Console.WriteLine(RunnerLegs.Run());
        }
    }
}
