﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simulation_StrategyPattern
{
    class Simulation
    {
        IWriter writer;
        Random rnd;
        int n;
       // int seed;

        public Simulation(int n, int seed, IWriter writer)
        {
            this.n = n;
           // this.seed = seed;
            this.writer = writer;
            this.rnd = new Random(seed);
        }

        public void Run()       // flip a coin and return heads 50% and tails 50%
        {
            for (int i = 0; i < this.n; i++)
            {
                string result = this.rnd.NextDouble() <= 0.5 ? "Heads" : "Tails";           // making use of random
                //Console.WriteLine(result);
                this.writer.Write(result);
            }
        }
    }
}
