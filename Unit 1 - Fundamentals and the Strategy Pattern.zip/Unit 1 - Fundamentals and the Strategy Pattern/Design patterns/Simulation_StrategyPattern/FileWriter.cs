﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simulation_StrategyPattern
{
    class FileWriter : IWriter
    {
        private string path;
        public FileWriter (string path)
        {
            this.path = path;
        }
        public void Write(string result)        // write "result" to path
        {
            Console.WriteLine("Writing" + result + "to" + path);
        }
    }
}

