﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic_OOP_Exercise
{
    class GameCharacter
    {
        public const int WIDTH = 20;
        public const int HEIGHT = 20;
        protected int xCoordinate;
        protected int yCoordinate;
        private string gameCharacter = "#";

        public GameCharacter(int xCoordinate, int yCoordinate, string gameCharacter)
        {
            this.xCoordinate = xCoordinate;
            this.yCoordinate = yCoordinate;
            this.gameCharacter = gameCharacter;
        }

        public virtual void Move()
        {
         
        }

  



        public bool Draw(int x, int y)
        {
            if(xCoordinate == x && yCoordinate == y)
            {
                Console.Write(gameCharacter);
                return true;
            }
            else
            {
                return false;
            }

        }

        public override string ToString()
        {
            return $"{xCoordinate},{yCoordinate},{gameCharacter}, {GetType()}";
        }


    }
}

