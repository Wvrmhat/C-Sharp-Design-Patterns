﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic_OOP_Exercise
{
    class VerticalMover : GameCharacter
    {
        private bool MoveDown { get; set;}

        public VerticalMover(int xCoordinate, int yCoordinate, string gameCharacter)
        : base(xCoordinate, yCoordinate, gameCharacter)
        {
            MoveDown = true;
        }

        public override void Move(int deltaX, int deltaY)
        {
            if(MoveDown)
            {
                yCoordinate += deltaY;
                MoveDown = false;
            }
            else
            {
                yCoordinate -= deltaY;
                MoveDown = true;
            }

            if(xCoordinate < 0 || xCoordinate >= HEIGHT)
            {
                MoveDown = !MoveDown;
            }
        }
    }
}
