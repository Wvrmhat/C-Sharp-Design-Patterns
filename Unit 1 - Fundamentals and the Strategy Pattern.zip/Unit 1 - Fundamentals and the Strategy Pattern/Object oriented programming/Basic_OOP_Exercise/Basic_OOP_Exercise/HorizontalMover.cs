﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic_OOP_Exercise
{
    class HorizontalMover : GameCharacter
    {
        private bool MoveRight { get; set; }
        

        public HorizontalMover(int xCoordinate, int yCoordinate, string gameCharacter) 
            : base(xCoordinate,yCoordinate,gameCharacter)
        {
            MoveRight = true;
        }

        public override void Move(int deltaX, int deltaY)
        {
            if(MoveRight)
            {
                xCoordinate += deltaX;
            }
            else
            {
                xCoordinate -= deltaX;
            }

            if(xCoordinate <0 || xCoordinate >= WIDTH)
            {
                MoveRight = !MoveRight;
            }
        }

        
    }
}
