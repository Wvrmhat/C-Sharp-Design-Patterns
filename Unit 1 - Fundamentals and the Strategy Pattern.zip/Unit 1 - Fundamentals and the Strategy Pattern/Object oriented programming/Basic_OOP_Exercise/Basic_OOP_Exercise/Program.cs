﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic_OOP_Exercise
{
    class Program
    {
        static void Main(string[] args)
        {
            int x;
            int y;
            GameCharacter[] characters = new GameCharacter[]
            {
                new HorizontalMover(10, 5, "#"),
                new HorizontalMover(13, 6, "#"),
                new VerticalMover(7, 15, "#"),
                new VerticalMover(4, 12, "#"),
            };

            char userInput;
            do
            {
                Console.Clear();
                foreach (var character in characters)
                {
                    character.Draw(character.x, character.y);
                    Console.WriteLine($"{character}");
                    character.Move();
               

                }
                Console.WriteLine("\nEnter 'e' to exit or any other key to continue:");

                userInput = Console.ReadKey().KeyChar;
            } while (userInput != 'e');
             
        }
    }
}
