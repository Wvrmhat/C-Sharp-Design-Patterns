﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Debonairs SouthAfrica = new SouthAfricanDebonairs();
            Debonairs China = new ChineseDebonairs();

            SouthAfrica.orderPizza("Cheese Pizza");
            China.orderPizza("Cheese Pizza");
            SouthAfrica.orderPizza("Double Cheese Pizza");
            China.orderPizza("Double Cheese Pizza");
            SouthAfrica.orderPizza("Meaty Pizza");
            China.orderPizza("Meaty Pizza");

            Console.ReadLine();
        }
    }
}
