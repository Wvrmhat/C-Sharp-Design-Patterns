﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryExample
{
    class ChinesePizzaIngredientFactory:PizzaIngredientFactory
    {
        public override IDough GetDough()
        {
            return new RiceFlourDough();
        }

        public override ISauce GetSauce()
        {
            return new SweetAndSourSauce();
        }

        public override ICheese GetCheese()
        {
            return new RatCheese();
        }

        public override IMeat GetMeat()
        {
            return new Pork();
        }

        public override IVeg GetVeg()
        {
            return new SpringOnion();
        }
    }
}
