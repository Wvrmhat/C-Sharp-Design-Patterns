﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryExample
{
    abstract class Debonairs
    {
        public PizzaIngredientFactory TheFactory { get; set; }

        public Debonairs(PizzaIngredientFactory TheFactory)
        {
            this.TheFactory = TheFactory;
        }

        public Pizza orderPizza(string PizzaType)
        {
            Pizza ThePizza = null;

            if (TheFactory != null)
            {
                ThePizza = makePizza(PizzaType);

                if (ThePizza != null)
                {
                    ThePizza.MakeDough();
                    ThePizza.AddToppings();
                    ThePizza.Bake();                    
                }
            }

            if (ThePizza == null)
                Console.WriteLine("This shop does not create the " + PizzaType);

            Console.WriteLine("-----------------------------------------------------------");

            return ThePizza;
        }

        public abstract Pizza makePizza(string PizzaType);
    }
}
