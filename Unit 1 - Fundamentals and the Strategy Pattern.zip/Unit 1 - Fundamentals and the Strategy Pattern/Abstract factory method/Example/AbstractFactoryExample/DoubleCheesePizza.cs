﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryExample
{
    class DoubleCheesePizza : Pizza
    {
        public DoubleCheesePizza(PizzaIngredientFactory TheFactory):base(TheFactory)
        {
            this.TheDough = TheFactory.GetDough();

            this.TheToppings.Add(TheFactory.GetSauce());
            this.TheToppings.Add(TheFactory.GetCheese());
            this.TheToppings.Add(TheFactory.GetCheese());
        }
    }
}
