﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryExample
{
    abstract class PizzaIngredientFactory
    {
        public abstract IDough GetDough();

        public abstract ISauce GetSauce();

        public abstract ICheese GetCheese();

        public abstract IMeat GetMeat();

        public abstract IVeg GetVeg();
    }
}
