﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryExample
{
    class ChineseDebonairs : Debonairs
    {
        public ChineseDebonairs() : base(new ChinesePizzaIngredientFactory())
        {

        }

        public override Pizza makePizza(string PizzaType)
        {
            Pizza ThePizza = null;

            if (TheFactory != null)
            {
                switch (PizzaType)
                {
                    case "Cheese Pizza": ThePizza = new CheesePizza(TheFactory); break;
                    // China doesn't eat double cheese pizza
                    //case "Double Cheese Pizza": ThePizza = new DoubleCheesePizza(TheFactory); break;
                    case "Meaty Pizza": ThePizza = new MeatyPizza(TheFactory); break;
                }
            }

            return ThePizza;
        }
    }
}
