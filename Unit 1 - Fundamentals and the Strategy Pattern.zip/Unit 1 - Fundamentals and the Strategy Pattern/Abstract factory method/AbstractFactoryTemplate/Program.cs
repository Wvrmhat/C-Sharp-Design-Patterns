﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    class Program
    {
        static void Main(string[] args)
        {
            BikeCo bikeCo = new SteelWorkshop(new SteelBicyclePartsFactory());
            Bike theBike = bikeCo.OrderBike("Mountain bike");
            theBike = bikeCo.OrderBike("Racing bike");
            theBike = bikeCo.OrderBike("Tricycle");
            bikeCo = new AluminiumWorkshop(new AluminiumBicyclePartsFactory());
            theBike = bikeCo.OrderBike("Mountain bike");
            theBike = bikeCo.OrderBike("Racing bike");
            theBike = bikeCo.OrderBike("Tricycle");
            Console.ReadLine();
        }
    }
}
