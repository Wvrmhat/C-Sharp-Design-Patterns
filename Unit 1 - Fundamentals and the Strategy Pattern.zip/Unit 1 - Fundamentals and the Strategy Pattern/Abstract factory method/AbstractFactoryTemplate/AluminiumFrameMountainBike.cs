﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    class AluminiumFrameMountainBike:AluminiumFrame
    {
        public AluminiumFrameMountainBike(BicyclePartsFactory theFactory) : base(theFactory)
        {
            this.theWheels = this.theFactory.GetMountainBikeWheels();
        }
        
    }
}
