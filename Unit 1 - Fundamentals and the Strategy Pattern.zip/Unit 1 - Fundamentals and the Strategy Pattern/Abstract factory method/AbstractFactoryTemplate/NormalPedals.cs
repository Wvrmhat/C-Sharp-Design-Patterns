﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    class NormalPedals : IPedals
    {
        public override string ToString()
        {
            return "Creating normal pedals.";
        }
    }
}
