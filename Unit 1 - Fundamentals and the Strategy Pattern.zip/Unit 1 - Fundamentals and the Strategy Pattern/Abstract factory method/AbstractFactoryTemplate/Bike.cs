﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    abstract class Bike
    {
        protected BicyclePartsFactory theFactory;
        protected IFrame theFrame;
        protected IWheels theWheels;
        protected IHandles theHandles;
        protected IBrakes theBrakes;
        protected IPedals thePedals;
        protected ISeat theSeat;

        public Bike(BicyclePartsFactory theFactory)
        {
            this.theFactory = theFactory;
            this.theFrame = theFactory.GetFrame();
            this.theWheels = theFactory.GetWheels();
            this.theHandles = theFactory.GetHandles();
            this.theBrakes = theFactory.GetBrakes();
            this.thePedals = theFactory.GetPedals();
            this.theSeat = theFactory.GetSeat();
        }
       
        public virtual void CreateFrame()
        {
            Console.WriteLine(theFrame);            
        }

        public virtual void AddWheels()
        {
            Console.WriteLine(theWheels);
        }

        public virtual void AddHandles()
        {
            Console.WriteLine(theHandles);
        }

        public virtual void AddBrakes()
        {
            Console.WriteLine(theBrakes);
        }

        public virtual void AddPedals()
        {
            Console.WriteLine(thePedals);
        }

        public virtual void AddSeat()
        {
            Console.WriteLine(theSeat);
        }
    }
}
