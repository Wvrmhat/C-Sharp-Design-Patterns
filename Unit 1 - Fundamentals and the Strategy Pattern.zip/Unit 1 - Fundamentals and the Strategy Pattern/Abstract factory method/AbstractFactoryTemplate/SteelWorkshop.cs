﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    class SteelWorkshop:BikeCo
    {
        public SteelWorkshop(BicyclePartsFactory theFactory) : base(theFactory)
        {
        }
        public override Bike BuildBike(string BikeName)
        {
            Bike theBike = null;

            if (BikeName == "Mountain bike")
                theBike = new SteelFrameMountainBike(this.theFactory);

            if (BikeName == "Tricycle")
                theBike = new SteelFrameTricycle(this.theFactory);

            return theBike;
        }
    }
}
