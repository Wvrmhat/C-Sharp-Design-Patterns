﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    class AluminiumFrameRacingBike:AluminiumFrame
    {
        public AluminiumFrameRacingBike(BicyclePartsFactory theFactory) : base(theFactory)
        {
            this.theWheels = this.theFactory.GetRacingWheels();
        }
    }
}
