﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    abstract class BikeCo			// Client
    {
        protected BicyclePartsFactory theFactory = null;

        public BikeCo(BicyclePartsFactory theFactory)
        {
            this.theFactory = theFactory;
        }
        public Bike OrderBike(string BikeName)
        {
            Bike ReturnMe = BuildBike(BikeName);

            if (ReturnMe != null)
            {
                Console.WriteLine("-------------------------------------------------");
                Console.WriteLine("Building:  " + ReturnMe.GetType().Name);
                Console.WriteLine("-------------------------------------------------");
                ReturnMe.CreateFrame();
                ReturnMe.AddWheels();
                ReturnMe.AddHandles();
                ReturnMe.AddBrakes();
                ReturnMe.AddPedals();
                ReturnMe.AddSeat();
                Console.WriteLine("-------------------------------------------------");
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("-------------------------------------------------");
                Console.WriteLine("We do not build this type of bike.");
                Console.WriteLine("-------------------------------------------------");
                Console.WriteLine();
            }

            return ReturnMe;
        }

        public abstract Bike BuildBike(string BikeName);
    }
}
