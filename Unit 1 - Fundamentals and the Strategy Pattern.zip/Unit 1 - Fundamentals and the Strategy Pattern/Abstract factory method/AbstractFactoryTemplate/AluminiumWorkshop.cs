﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    class AluminiumWorkshop:BikeCo
    {
        public AluminiumWorkshop(BicyclePartsFactory theFactory):base(theFactory)
        {
        }
        public override Bike BuildBike(string BikeName)
        {
            Bike theBike = null;

            if (BikeName == "Mountain bike")
                theBike = new AluminiumFrameMountainBike(this.theFactory);

            if (BikeName == "Racing bike")
                theBike = new AluminiumFrameRacingBike(this.theFactory);

            return theBike;
        }
    }
}
