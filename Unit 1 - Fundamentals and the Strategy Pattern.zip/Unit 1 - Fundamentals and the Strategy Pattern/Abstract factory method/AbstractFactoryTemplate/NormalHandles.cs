﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    class NormalHandles : IHandles
    {
        public override string ToString()
        {
            return "Creating normal handles.";
        }
    }
}
