﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    class Client
    {
        BicyclePartsFactory TheFactory = null;
        public AbstractProductA ProductA = null;
        public AbstractProductB ProductB = null;
        public Client (BicyclePartsFactory TheFactory)
        {
            this.TheFactory = TheFactory;
            this.ProductA = TheFactory.CreateProductA();
            this.ProductB = TheFactory.CreateProductB();
        }
    }
}
