﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    abstract class BicyclePartsFactory
    {
        public abstract IFrame GetFrame();
        public abstract IWheels GetWheels();
        public abstract IWheels GetRacingWheels();
        public abstract IWheels GetMountainBikeWheels();

        public abstract IWheels GetTricycleWheels();

        public abstract IHandles GetHandles();

        public abstract IBrakes GetBrakes();

        public abstract IPedals GetPedals();

        public abstract ISeat GetSeat();
    }
}
