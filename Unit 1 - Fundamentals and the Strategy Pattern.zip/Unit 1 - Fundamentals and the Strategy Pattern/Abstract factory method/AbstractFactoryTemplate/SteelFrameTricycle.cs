﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    class SteelFrameTricycle:SteelFrame
    {
        public SteelFrameTricycle(BicyclePartsFactory theFactory) : base(theFactory)
        {
            this.theWheels = this.theFactory.GetTricycleWheels();
        }
    }
}
