﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryTemplate
{
    class AluminiumBicyclePartsFactory : BicyclePartsFactory
    {
        public override IBrakes GetBrakes()
        {
            return new HydraulicBrakes();
        }

        public override IFrame GetFrame()
        {
            return new AluminiumBikeFrame();
        }

        public override IHandles GetHandles()
        {
            return new NormalHandles();
        }

        public override IWheels GetMountainBikeWheels()
        {
            return new MountainBikeWheels();
        }

        public override IPedals GetPedals()
        {
            return new NormalPedals();
        }

        public override IWheels GetRacingWheels()
        {
            return new RacingWheels();
        }

        public override IWheels GetTricycleWheels()
        {
            return new TricycleWheels();
        }

        public override ISeat GetSeat()
        {
            return new NormalSeat();
        }

        public override IWheels GetWheels()
        {
            return new NormalWheels();
        }
    }
}
