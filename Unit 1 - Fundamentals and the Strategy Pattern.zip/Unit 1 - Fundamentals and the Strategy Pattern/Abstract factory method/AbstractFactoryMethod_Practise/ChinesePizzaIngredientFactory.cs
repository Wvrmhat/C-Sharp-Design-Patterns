﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryMethod_Practise
{
    class ChinesePizzaIngredientFactory : PizzaIngredientFactory    // concrete factory version B
    {
        public override IDough GetDough()
        {
            return new RiceFlourDough();
        }

        public override ISauce GetSauce()
        {
            return new SweetAndSourSauce();
        }

        public override ICheese GetCheese()
        {
            return new Cheddar();
        }

        public override IMeat GetMeat()
        {
            return new Pork();
        }

        public override IVeg GetVeg()
        {
            return new Onion();
        }
    }
}
