﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryMethod_Practise
{
    class Debonairs         // Client base class
    {
        public PizzaIngredientFactory TheFactory { get; set; }
        public Debonairs(PizzaIngredientFactory TheFactory)     // the place where it gets it's dough, resources from etc..
        {
            this.TheFactory = TheFactory;
        }

        public Pizza orderPizza(string PizzaType)       //  method 
        {
            Pizza ThePizza = null;

            if(TheFactory != null)
            {
                ThePizza = makePizza(PizzaType);
                
                if(ThePizza != null)
                {
                    ThePizza.MakeDough();
                    ThePizza.AddToppings();
                    ThePizza.Bake();
                }
            }

            if (ThePizza == null)
                Console.WriteLine("This shop does not create the " + PizzaType);

            Console.WriteLine("------------------------------------------------");

            return ThePizza;
        }

        public abstract Pizza makePizza(string PizzaType);      // factory method of makePizza, concrete version of client needs to implement this.
    }
}
