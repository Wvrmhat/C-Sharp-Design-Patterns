﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryMethod_Practise
{
    class CheesePizza : Pizza   // Does not depend on any concrete object
    {
        public CheesePizza(PizzaIngredientFactory TheFactory): base(TheFactory)     // Handles creation
        {
            this.TheDough = TheFactory.GetDough();

            this.TheToppings.Add(TheFactory.GetSauce());
            this.TheToppings.Add(TheFactory.GetCheese());
        }
    }
}
