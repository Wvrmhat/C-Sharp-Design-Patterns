﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryMethod_Practise
{
    abstract class Pizza
    {
        public IDough TheDough { get; set; }
        public List<ITopping> TheToppings { get; set; }
        public PizzaIngredientFactory TheFactory { get; set; }


        public Pizza(PizzaIngredientFactory TheFactory)
        {
            this.TheToppings = new List<ITopping>();
            this.TheFactory = TheFactory;

            Console.WriteLine("Creating {0}", this.GetType().Name);
        }

        public virtual void MakeDough()
        {
            Console.WriteLine("Making {0} pizza base", TheDough,GetType().Name);

           

        }

        public virtual void AddToppings()
        {
            Console.WriteLine("Adding toppings:");

            foreach (ITopping Current in TheToppings)
                Console.WriteLine("- {0}", Current.GetType().Name);
        }

        public virtual void Bake()
        {
            Console.WriteLine("Baking the pizza");
        }
    }
}
