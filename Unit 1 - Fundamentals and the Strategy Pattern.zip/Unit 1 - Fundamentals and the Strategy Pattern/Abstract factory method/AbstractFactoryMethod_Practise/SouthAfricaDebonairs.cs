﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryMethod_Practise
{
    class SouthAfricaDebonairs : Debonairs
    {
        public SouthAfricaDebonairs() : base (new SouthAfricanPizzaIngredientFactory()) // composes with the south african ingredient concrete factory
        {

        }

        public override Pizza makePizza(string PizzaType)
        {
            Pizza ThePizza = null;

            if(TheFactory != null)
            {
                switch(PizzaType)       // parses factories through to their products?
                {
                    case "Cheese Pizza": ThePizza = new CheesePizza(TheFactory); break; //can create various kinds, we want to create a cheese pizza
                    case "Meaty Pizza": ThePizza = new MeatyPizza(TheFactory); break;
                }
            }
            return ThePizza;
        }
    }
}
