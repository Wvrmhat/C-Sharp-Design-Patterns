﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryMethod_Practise
{
    class Program
    {
        static void Main(string[] args)
        {
            Debonairs SouthAfrica = new SouthAfricaDebonairs();

            SouthAfrica.orderPizza("Cheese Pizza");
            SouthAfrica.orderPizza("Meaty Pizza");


            Console.ReadLine();
        }
    }
}
