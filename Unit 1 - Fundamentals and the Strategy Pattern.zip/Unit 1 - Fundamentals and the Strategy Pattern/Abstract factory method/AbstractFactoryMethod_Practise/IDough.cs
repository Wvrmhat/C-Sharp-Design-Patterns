﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryMethod_Practise
{
    interface IDough    // acts as a grouping structure, ties all different types of dough together. (Abstract product
    {
    }
}
