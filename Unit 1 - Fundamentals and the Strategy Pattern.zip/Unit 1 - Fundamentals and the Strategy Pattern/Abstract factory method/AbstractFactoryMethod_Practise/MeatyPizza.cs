﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryMethod_Practise
{
    class MeatyPizza : Pizza
    {
        public MeatyPizza(PizzaIngredientFactory TheFactory) : base(TheFactory)
        {
            this.TheDough = TheFactory.GetDough();

            this.TheToppings.Add(TheFactory.GetSauce());
            this.TheToppings.Add(TheFactory.GetCheese());
            this.TheToppings.Add(TheFactory.GetMeat());
            this.TheToppings.Add(TheFactory.GetVeg());
        }
    }
}
