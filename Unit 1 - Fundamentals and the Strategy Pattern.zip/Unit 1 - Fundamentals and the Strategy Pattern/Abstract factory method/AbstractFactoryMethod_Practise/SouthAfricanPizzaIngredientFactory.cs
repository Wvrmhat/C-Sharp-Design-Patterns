﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryMethod_Practise
{
    class SouthAfricanPizzaIngredientFactory : PizzaIngredientFactory       // a version of concrete factory
    {
        public override IDough GetDough()
        {
            return new WheatDough();
        }

        public override ISauce GetSauce()
        {
            return new TomatoSauce();
        }

        public override ICheese GetCheese()
        {
            return new Cheddar();
        }

        public override IMeat GetMeat()
        {
            return new Chicken();
        }

        public override IVeg GetVeg()
        {
            return new SpringOnion();
        }
    }
}
