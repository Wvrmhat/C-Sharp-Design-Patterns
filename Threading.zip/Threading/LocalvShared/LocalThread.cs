﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace LocalvShared
{
    class LocalThread
    {
        public void RunThread()
        {
            Thread DisplayThread = new Thread(new ThreadStart(DisplayNum));
            new Thread(DisplayNum).Start();
            DisplayNum();

            Console.WriteLine();
            Thread bDisplayThread = new Thread(new ThreadStart(bDisplayNum));
            new Thread(bDisplayNum).Start();
            bDisplayNum();
        }

        private static void DisplayNum()
        {
            int number = 10;
            for(int i = 0; i < number;i++)
            {
                Console.Write(i);
            }
        }

        static bool completed = false;

        public static void bDisplayNum()
        {
            if (!completed)
            {
                completed = true;
                Console.WriteLine(completed);
            }
        }




    }
}
