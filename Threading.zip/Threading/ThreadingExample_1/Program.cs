﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadingExample_1
{
    class Program
    {
        static void Main(string[] args)
        {

            RunningThreads example = new RunningThreads();
            example.RunThreads();                       // method that creates new thread for the worker and starts it

            RunningThreads SharedData = new RunningThreads();
            SharedData.RunThreads();

            Console.ReadLine();
        }


    }
}
