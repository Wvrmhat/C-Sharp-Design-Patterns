﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadingExample_1
{
    class RunningThreads
    {
        public void RunThreads()
        {
            ////Thread workerThread = new Thread(new ThreadStart(Worker));      //Creates thread with specified method
            ////workerThread.Start();                                           //Starts runnigng the Worker method on the new thread
            Thread DisplayThread = new Thread(new ThreadStart(DisplayNumb));
            new Thread(DisplayNumb).Start();
            DisplayNumb();


            for (int i = 0; i < 10; i++)                  // simultaneously performs work on main thread
            {
                Console.Write(1);
            }
            Console.ReadLine();
            DisplayThread.Join();                             // waits for worker thread to finish by blocking the current one.
            Console.WriteLine("\nMain thread is complete.");
        }


        private void Worker()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.Write(0);
                Thread.Sleep(TimeSpan.FromMilliseconds(500));
               // Console.Write("\nWorker thread is done.");
            }
        }

        private static void DisplayNumb()
        {


            int number = 10;
            for(int i = 0; i < number; i++)
            {
                Console.Write(i);
            }
        }


    }


}
