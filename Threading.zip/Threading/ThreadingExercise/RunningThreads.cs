﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadingExercise
{
    class RunningThreads
    {
       public void RunThreads()
        {
            int a = 0;
            int b = 0;

            Thread ThreadOne = new Thread(new ThreadStart(FirstThread));
            new Thread(FirstThread).Start();
            FirstThread();

            Thread ThreadTwo = new Thread(new ThreadStart(SecondThread));
            new Thread(SecondThread).Start();
            SecondThread();

            Thread ThreadThree = new Thread(new ThreadStart(ThirdThread));
            new Thread(ThirdThread).Start();
            ThreadOne.Join();                                           //Waits for first thread to finish
            ThirdThread();
            

            Thread ThreadFour = new Thread(() => FourthThread(a, b));
            ThreadTwo.Join();                                          //Starts fourth thread after second thread has completed
            ThreadFour.Start();


        }


       public void FirstThread()
        { 
            for(int i = 1; i <= 10000; i++)
            {
                Console.Write(i);
               // Thread.Sleep(TimeSpan.FromMilliseconds(0.1));
                
            }
        }

        public void SecondThread()
        {
            for(int i = 1; i <= 5000; i++)
            {
                Console.Write(i);
                Thread.Sleep(TimeSpan.FromMilliseconds(100));
            }
        }

        public void ThirdThread()
        {
            for(char alphabet = 'A'; alphabet <= 'Z'; alphabet++)
            {
                Console.Write(alphabet);
                Thread.Sleep(TimeSpan.FromSeconds(1));
            }
        }

        public void FourthThread(int a, int b)
        {
            Random num1 = new Random(a);
            Random num2 = new Random(b);

            for(int i = 1; i <= 100; i++)
            {
                Console.Write(a + b);
            }
        }




    }
}
