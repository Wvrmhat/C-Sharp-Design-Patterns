﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreadingExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            RunningThreads threads = new RunningThreads();
            threads.RunThreads();

            Console.ReadLine();
        }
    }
}
