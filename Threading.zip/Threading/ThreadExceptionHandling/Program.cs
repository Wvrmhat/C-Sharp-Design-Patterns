﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread nt = new Thread(() => Division(10, 0));
            nt.Start();
            Console.ReadLine();

        }

        public static void Division(int num, int num2)
        {
            try
            {
                Console.WriteLine(num % num2);
            }
            catch(Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
        }
    }
}
