﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace LambdaExp
{
    class PassingData
    {
        public static void DisplayNum(object num)
        {
 
            int number = Convert.ToInt32(num); // Casting

            for(int i = 0; i < number; i++)
            {
                Console.Write(i);
            }
        }


    }
}
