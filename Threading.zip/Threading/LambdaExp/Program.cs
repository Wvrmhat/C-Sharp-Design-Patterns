﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace LambdaExp
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread add = new Thread(() => Addition(5, 10));
            add.Start();

            PassingData pData = new PassingData();
            PassingData.DisplayNum(pData);
           
            

            Console.ReadLine();
        }

        public static void Addition(int num, int num2)
        {
            Console.WriteLine(num + num2);
        }
    }
}
