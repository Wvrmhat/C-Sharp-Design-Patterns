﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingletonExample
{
    class Program
    {
        static void Main(string[] args)
        {
            DecimalKeeper Keeper1 = DecimalKeeper.GetInstance();
            Console.WriteLine("Keeper 1: " + Keeper1.TheValue.ToString());
            Keeper1.TheValue += 20;

            DecimalKeeper Keeper2 = DecimalKeeper.GetInstance();
            Console.WriteLine("Keeper 2: " + Keeper2.TheValue.ToString());
            Keeper2.TheValue += 20;
            Console.WriteLine("Keeper 1: " + Keeper1.TheValue.ToString());
            Console.ReadLine();
        }
    }
}
