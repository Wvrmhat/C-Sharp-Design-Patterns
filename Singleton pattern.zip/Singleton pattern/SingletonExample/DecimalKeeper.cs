﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingletonExample
{
    public sealed class DecimalKeeper      //singleton objectType                 // cannot inherit from this class since it is "sealed"
    {
        private static DecimalKeeper _instance;             // field that instance is stored, this is the Singleton field
        private static object _lockThis = new object();     // static object lock

        public decimal TheValue { get; set; }

        private DecimalKeeper()                 //  constructor declared private since it is for singleton. Private means it can only be accessed in this class.
        {
            TheValue = 0;
        }

        public static DecimalKeeper GetInstance()       // static method to have access to private static DecimaleKeeper
        {
            lock(_lockThis)                             // ensure that the instance is not created twice, only one thread at a time
            {
                if(_instance == null)                   // checks if instance is set to null, then it creates it. If it runs again after creating, the instance is no longer null so then it returns the instance itself.
                {
                    _instance = new DecimalKeeper();
                }

                return _instance;
            }
        }
    }
}
