﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Singleton_RndGen
{
    public sealed class GenNumber
    {
        private volatile static GenNumber _RndGen;
        private static readonly object _lockThis = new object();
        private long count;
        Random rGen;
        //private RandomGenerator()
        //{
        //    int count = 0;
        //    count++;
            
        //}

        private int GenSeed()
        {
            return (int)DateTime.Now.Ticks;
        }

        private GenNumber()
        {
            int seed = GenSeed();
            rGen = new Random(seed);

          
        }

        public int Generate(int low, int high)
        {
            //const long x = 1557636;
            //const long y = 1013904223;
            //const long z = 42896967296;

            //count = (x * count + y) % z;
            //return (int)(low + count % (high - low));

            return rGen.Next(low, high + 1);

        }

        public static GenNumber GetRandom()
        {
            if(_RndGen == null)
            {
                lock (_lockThis)
                {
                    if (_RndGen == null)
                        _RndGen = new GenNumber();
                }  
            }
            return _RndGen;
        }

    }
}
