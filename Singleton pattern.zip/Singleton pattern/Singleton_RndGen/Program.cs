﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Singleton_RndGen
{
    class Program
    {
        static void Main(string[] args)
        {
            //Thread thread1 = new Thread(Singleton);
            //thread1.Name = "First Thread:";
            //thread1.Start();

            GenNumber firstGen = GenNumber.GetRandom();
            Console.WriteLine("First Gen: {0} ", firstGen.Generate(1, 1000));

            GenNumber secondGen = GenNumber.GetRandom();
        
            for(int i = 0; i < 1000; i++)
            {
                Console.WriteLine(secondGen.Generate(1, 100));
            }    


            Console.ReadLine();
        }

        public static void Singleton()
        {
            GenNumber ss1 = GenNumber.GetRandom();
            ss1.Generate(1,1000);
        }
    }
}
