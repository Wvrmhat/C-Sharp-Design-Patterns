﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SingletonPractical
{
    class RandomGenerator
    {
        private static volatile RandomGenerator theGenerator = null;
        private static volatile object myLock = new object();
        Random rGenerator;
        private int? Seed;

        private RandomGenerator() 
        {
            rGenerator = new Random();
            //this.Seed = ExtractSeed(DateTime.Now.Ticks.ToString());
        }

        public static RandomGenerator GetGenerator()
        {
            lock (myLock)
            {
                if (theGenerator == null)
                    theGenerator = new RandomGenerator();
            }

            return theGenerator;
        }

        public int Generate(int Lowest, int Highest)
        {
            return rGenerator.Next(Lowest, Highest + 1);
            //lock (myLock)
            //{
            //    int squareValue = (int)Math.Pow((double)this.Seed, 2);
            //    theGenerator.Seed = ExtractSeed(squareValue.ToString());

            //    string squareString = squareValue.ToString();

            //    while (squareString.Length < 4)
            //        squareString = "1" + squareString;

            //    squareValue = int.Parse(squareString);

            //    double value = double.Parse(squareValue.ToString().Substring(squareValue.ToString().Length / 2 - 2, 4));
            //    double calculated = ((value / 9999) * Highest) + Lowest;

            //    if (calculated > Highest)
            //        calculated = Highest;

            //    return (int)calculated;
            //}
        }

        private static int ExtractSeed(string seedString)
        {
            try
            {
                seedString = seedString.Substring(seedString.Length - 4, 4);

                if (seedString[0] == '1')
                    seedString = "1" + seedString.Substring(1);

                while (seedString.Length < 4)
                    seedString = "1" + seedString;

                return int.Parse(seedString);
            }
            catch
            {
                return ExtractSeed(DateTime.Now.Ticks.ToString());
            }
        }
    }
}
