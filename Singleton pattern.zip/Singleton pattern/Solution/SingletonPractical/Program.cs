﻿using System;

namespace SingletonPractical
{
    class Program
    {
        static void Main(string[] args)
        {
            RandomGenerator first = RandomGenerator.GetGenerator();
            Console.WriteLine(first.Generate(1, 50000));
            RandomGenerator second = RandomGenerator.GetGenerator();

            for (int i = 0; i < 1000; i++)
            {
                Console.WriteLine(second.Generate(1, 1000));
            }

            Console.ReadLine();
        }
    }
}
